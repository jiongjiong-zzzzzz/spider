package DATA;

public class aaaa {
    public static void main(String[] args){
        java.awt.Toolkit.getDefaultToolkit().beep();
    }
}
